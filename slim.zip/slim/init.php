<?php
// diretório base da aplicação
define('BASE_PATH', dirname(__FILE__));
 
// credenciais de acesso ao MySQL
// define('MYSQL_HOST', 'DESKTOP-18UAMD2');
// define('MYSQL_USER', 'sa');
// define('MYSQL_PASS', 'senha');
// define('MYSQL_DBNAME', 'DB7897DES');

// credenciais de acesso ao MySQL
define('SQLSRV_HOST', 'DESKTOP-18UAMD2');
define('SQLSRV_USER', 'sa');
define('SQLSRV_PASS', 'senha');
define('SQLSRV_DBNAME', 'DB7897DES');


 
// configurações do PHP
ini_set('display_errors', true);
error_reporting(E_ALL);
date_default_timezone_set('America/Sao_Paulo');