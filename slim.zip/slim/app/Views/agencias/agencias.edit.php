<h2>Edição de Agencia</h2>
 
<?php echo json_encode($agencia); ?>

