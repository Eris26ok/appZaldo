<h1>Lista de Agências</h1>
 
<?php echo json_encode($agencias); ?>

<a href="/agencias/add">Adicionar Agência</a>

<?php if (count($agencias) > 0): ?>
 
<table width="50%" border="1" cellpadding="2" cellspacing="0">
 
<thead>
 
<tr>
 
<th>[nu_cgc]</th>
 
<th>[nu_cgc_dv]</th>
 
<th>[no_tipo_pv]</th>
 
<th>[no_situacao]</th>
 
<th>[no_agencia]</th>
 
<th>[no_endereco]</th>

<th>[no_bairro]</th>
<th>[nu_cep]</th>
<th>[no_responsavel]</th>
<th>[no_matricula_resp]</th>
<th>[no_caixa_mail]</th>
<th>[no_subordinacao]</th>
<th>[nu_ddd]</th>
<th>[nu_contato]</th>

<th>Controles</th>
 
        </tr>
 
    </thead>
 
<tbody>
        <?php foreach ($agencias as $agencia): ?>
 
<tr>
 
<td><?php echo $agencia['nu_cgc']; ?></td>
 
<td><?php echo $agencia['nu_cgc_dv']; ?></td>
 
<td><?php echo $agencia['no_tipo_pv']; ?></td>
 
<td><?php echo $agencia['no_situacao']; ?></td>
 
<td><?php echo $agencia['no_agencia']; ?></td>
<td><?php echo $agencia['no_endereco']; ?></td>
<td><?php echo $agencia['no_bairro']; ?></td>
<td><?php echo $agencia['nu_cep']; ?></td>
<td><?php echo $agencia['no_responsavel']; ?></td>
<td><?php echo $agencia['no_matricula_resp']; ?></td>
<td><?php echo $agencia['no_caixa_mail']; ?></td>
<td><?php echo $agencia['no_subordinacao']; ?></td>
<td><?php echo $agencia['nu_ddd']; ?></td>
<td><?php echo $agencia['nu_contato']; ?></td>

 
<td>
                <a href="/agencias/edit/<?php echo $agencia['id']; ?>">Editar</a>
                <a href="/agencias/remove/<?php echo $agencia['id']; ?>" onclick="return confirm('Tem certeza de que deseja remover?');">Remover</a>
            </td>
 
        </tr>
 
        <?php endforeach; ?>
    </tbody>
 
</table>
 
 
<?php else: ?>
 
 
 
Nenhuma agencia cadastrada
 
 
<?php endif; ?>