<!-- make sure the attribute enctype is set to multipart/form-data -->
<form method="post" action="/deps/upload" enctype="multipart/form-data">
    <!-- upload of a single file -->
    <p>
        <label>Escolha o arquivo Dep: </label><br/>
        <input type="file" name="dep-upload"/>
    </p>

    <p>
        <input type="submit"/>
    </p>
</form>