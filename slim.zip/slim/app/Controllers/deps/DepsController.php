<?php

namespace App\Controllers\deps;
use \App\Models\deps\Dep;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class DepsController {

    /** * Listagem de usuários */
    public function index() {
        $deps = Dep::selectAll();
        \App\View::make('deps/deps.upload', 
        [ 'deps' => $deps,]);
    }


    /** * Tela de Upload */
    public function telaUpload() {
        $deps = [];
        \App\View::make('deps/deps.upload', 
        [ 'deps' => $deps,]);

    }

    public function uploadTela() {

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'Hello World !');

        $writer = new Xlsx($spreadsheet);
        $writer->save('./uploads/hello world33.xlsx');

    }
 
    /**
     * Exibe o formulário de criação de usuário
     */
    public function create()
    {
        \App\View::make('agencias/agencias.create');
    }
 
    /**
     * Processa o formulário de criação de usuário
     */
    public function store()
    {
        // pega os dados do formuário
        $name = isset($_POST['name']) ? $_POST['name'] : null;
        $email = isset($_POST['email']) ? $_POST['email'] : null;
        $gender = isset($_POST['gender']) ? $_POST['gender'] : null;
        $birthdate = isset($_POST['birthdate']) ? $_POST['birthdate'] : null;
 
        if (Agencia::save($name, $email, $gender, $birthdate))
        {
            header('Location: /agencias');
            exit;
        }
    }
 
 
 
    /**
     * Exibe o formulário de edição de usuário
     */
    public function edit($id)
    {
        $agencia = Agencia::selectAll($id)[0];
 
        \App\View::make('agencias/agencias.edit',[
            'agencia' => $agencia,
        ]);
    }
 
 
    /**
     * Processa o formulário de edição de usuário
     */
    public function update()
    {
        // pega os dados do formuário
        $id = $_POST['id'];
        $name = isset($_POST['name']) ? $_POST['name'] : null;
        $email = isset($_POST['email']) ? $_POST['email'] : null;
        $gender = isset($_POST['gender']) ? $_POST['gender'] : null;
        $birthdate = isset($_POST['birthdate']) ? $_POST['birthdate'] : null;
 
        if (Agencia::update($id, $name, $email, $gender, $birthdate))
        {
            header('Location: /agencias');
            exit;
        }
    }
 
 
    /**
     * Remove um usuário
     */
    public function remove($id)
    {
        if (Agencia::remove($id))
        {
            header('Location: /agencias');
            exit;
        }
    }
}