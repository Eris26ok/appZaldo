<?php

namespace App\Controllers\agencias;
use \App\Models\agencias\Agencia;

class AgenciasController {

    /** * Listagem de usuários */ 
    public function index() {
        $agencias = Agencia::selectAll(); 
        \App\View::make('agencias/agencias.index', 
        [ 'agencias' => $agencias,]);
    }
 
    /**
     * Exibe o formulário de criação de usuário
     */
    public function create()
    {
        \App\View::make('agencias/agencias.create');
    }
 
 
    /**
     * Processa o formulário de criação de usuário
     */
    public function store()
    {
        // pega os dados do formuário
        $name = isset($_POST['name']) ? $_POST['name'] : null;
        $email = isset($_POST['email']) ? $_POST['email'] : null;
        $gender = isset($_POST['gender']) ? $_POST['gender'] : null;
        $birthdate = isset($_POST['birthdate']) ? $_POST['birthdate'] : null;
 
        if (Agencia::save($name, $email, $gender, $birthdate))
        {
            header('Location: /agencias');
            exit;
        }
    }
 
 
 
    /**
     * Exibe o formulário de edição de usuário
     */
    public function edit($id)
    {
        $agencia = Agencia::selectAll($id)[0];
 
        \App\View::make('agencias/agencias.edit',[
            'agencia' => $agencia,
        ]);
    }
 
 
    /**
     * Processa o formulário de edição de usuário
     */
    public function update()
    {
        // pega os dados do formuário
        $id = $_POST['id'];
        $name = isset($_POST['name']) ? $_POST['name'] : null;
        $email = isset($_POST['email']) ? $_POST['email'] : null;
        $gender = isset($_POST['gender']) ? $_POST['gender'] : null;
        $birthdate = isset($_POST['birthdate']) ? $_POST['birthdate'] : null;
 
        if (Agencia::update($id, $name, $email, $gender, $birthdate))
        {
            header('Location: /agencias');
            exit;
        }
    }
 
 
    /**
     * Remove um usuário
     */
    public function remove($id)
    {
        if (Agencia::remove($id))
        {
            header('Location: /agencias');
            exit;
        }
    }
}