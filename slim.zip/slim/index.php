<?php
// composer dump-autoload -o

// inclui o autoloader do Composer
require 'vendor/autoload.php';
// inclui o arquivo de inicialização
require 'init.php';


use Slim\Http\Request;
use Slim\Http\Response;
use Slim\Http\UploadedFile;

// $app = new \Slim\App(); //produção
// instancia o Slim, habilitando os erros (útil para debug, em desenvolvimento)
$app = new \Slim\App([ 'settings' => [
        'displayErrorDetails' => true
    ]
]);


// TODAS AS ROTAS

  // listagem de usuários
  $app->get('/usuarios', function ()
  {
      $UsersController = new \App\Controllers\usuarios\UsersController;
      $UsersController->index();
  });


  // adição de usuário
  // exibe o formulário de cadastro
  $app->get('/usuarios/add', function ()
  {
      $UsersController = new \App\Controllers\usuarios\UsersController;
      $UsersController->create();
  });

  // processa o formulário de cadastro
  $app->post('/usuarios/add', function ()
  {
      $UsersController = new \App\Controllers\usuarios\UsersController;
      $UsersController->store();
  });


  // edição de usuário
  // exibe o formulário de edição
  $app->get('/usuarios/edit/{id}', function ($request)
  {
      // pega o ID da URL
      $id = $request->getAttribute('id');

      $UsersController = new \App\Controllers\usuarios\UsersController;
      $UsersController->edit($id);
  });

  // processa o formulário de edição
  $app->post('/usuarios/edit', function ()
  {
      $UsersController = new \App\Controllers\usuarios\UsersController;
      $UsersController->update();
  });

  // remove um usuário
  $app->post('/usuarios/remove/{id}', function ($request)
  {
      // pega o ID da URL
      $id = $request->getAttribute('id');

      $UsersController = new \App\Controllers\usuarios\UsersController;
      $UsersController->remove($id);
  });


  /* =============================================== */




  // listagem de AGENCIAS
  $app->get('/agencias', function ()
  {
      $AgenciasController = new \App\Controllers\agencias\AgenciasController;
      $AgenciasController->index();
  });


  // processa o formulário de cadastro
  $app->post('/agencias/add', function ()
  {
      $AgenciasController = new \App\Controllers\agencias\AgenciasController;
      $AgenciasController->store();
  });


  // edição de AGENCIA
  // exibe o formulário de edição
  $app->get('/agencias/edit/{id}', function ($request)
  {
      // pega o ID da URL
      $id = $request->getAttribute('id');

      $AgenciasController = new \App\Controllers\agencias\AgenciasController;
      $AgenciasController->edit($id);
  });

  // processa o formulário de edição
  $app->post('/agencias/edit', function ()
  {
      $AgenciasController = new \App\Controllers\agencias\AgenciasController;
      $AgenciasController->update();
  });

  // remove uma AGENCIA
  $app->post('/agencias/remove/{id}', function ($request)
  {
      // pega o ID da URL
      $id = $request->getAttribute('id');

      $AgenciasController = new \App\Controllers\agencias\AgenciasController;
      $AgenciasController->remove($id);
  });







  /* =============================================== */




  // Tela de upload

  $app->get('/deps/{id}', function ($request)
  {
      // pega o ID da URL
      $id = $request->getAttribute('id');

      $DepsController = new \App\Controllers\deps\DepsController;
      $DepsController->telaUpload();

  });

  //upload
  $container = $app->getContainer();
  $container['upload_directory'] = __DIR__ . '/uploads';

  $app->post('/deps/upload', function(Request $request, Response $response) {

      $DepsController = new \App\Controllers\deps\DepsController;
      $DepsController->uploadTela();

      $directory = $this->get('upload_directory');
      $uploadedFiles = $request->getUploadedFiles();

      // handle single input with single file upload
      $uploadedFile = $uploadedFiles['dep-upload'];
      if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
          $filename = moveUploadedFile($directory, $uploadedFile);
          $response->write('uploaded ' . $filename . '<br/>');
      }
      // header('Location: /deps');
      // exit;

  });

  // remove uma AGENCIA
  $app->post('/deps/remove/{id}', function ($request)
  {
      // pega o ID da URL
      $id = $request->getAttribute('id');

      $DepsController = new \App\Controllers\deps\DepsController;
      $DepsController->remove($id);
  });

  function moveUploadedFile($directory, UploadedFile $uploadedFile)
  {
      $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
      $basename = bin2hex(random_bytes(8)); // see http://php.net/manual/en/function.random-bytes.php
      $filename = sprintf('%s.%0.8s', $basename, $extension);

      $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $filename);

      return $filename;
  }

$app->run();
